import { config } from '../config/index.js'

export function distanceBetween(a, b) {
  const rad = (value) => value * Math.PI / 180

  const dLat = rad(b.latitude - a.latitude)
  const dLon = rad(b.longitude - a.longitude)

  const value =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.latitude)) *
      Math.cos(rad(b.latitude)) *
      Math.sin(dLon / 2) ** 2

  return Math.round(
    6371000 *
      2 *
      Math.atan2(Math.sqrt(value), Math.sqrt(1 - value))
  )
}

function secondsFromDuration(value) {
  return Math.max(
    1,
    Math.round(
      Number.parseFloat(String(value).replace('s', '')) || 0
    )
  )
}

export async function routeEta(origin, destination, intermediateStops = []) {
  /*
   * ------------------------------------------------------------
   * VALIDATE COORDINATES
   * ------------------------------------------------------------
   */

  const normalizeCoordinates = (point) => ({
    latitude: Number(point?.latitude),
    longitude: Number(point?.longitude)
  })

  const normalizedOrigin = normalizeCoordinates(origin)
  const normalizedDestination = normalizeCoordinates(destination)

  const normalizedStops = intermediateStops.map(normalizeCoordinates)

  const allCoordinates = [
    normalizedOrigin,
    ...normalizedStops,
    normalizedDestination
  ]

  const validCoordinates = allCoordinates.every(
    (point) =>
      Number.isFinite(point.latitude) &&
      Number.isFinite(point.longitude) &&
      point.latitude >= -90 &&
      point.latitude <= 90 &&
      point.longitude >= -180 &&
      point.longitude <= 180
  )

  if (!validCoordinates) {
    throw Object.assign(
      new Error('Invalid GPS coordinates supplied to Google Routes API.'),
      { status: 400 }
    )
  }

  /*
   * ------------------------------------------------------------
   * DEMO MODE
   * ------------------------------------------------------------
   */

  if (!config.googleMapsApiKey) {
    if (!config.demoMode) {
      throw Object.assign(
        new Error(
          'Google Routes is not configured. Add GOOGLE_MAPS_API_KEY or enable demo mode.'
        ),
        { status: 503 }
      )
    }

    let totalDistanceMeters = 0

    for (let i = 0; i < allCoordinates.length - 1; i++) {
      totalDistanceMeters += distanceBetween(
        allCoordinates[i],
        allCoordinates[i + 1]
      )
    }

    const durationSeconds = Math.max(
      60,
      Math.round(totalDistanceMeters / (25 * 1000 / 3600))
    )

    return {
      distanceMeters: totalDistanceMeters,
      durationSeconds,
      trafficCondition: 'UNKNOWN',
      source: 'demo',
      encodedPolyline: null,
      polyline: null
    }
  }

  /*
   * ------------------------------------------------------------
   * GOOGLE ROUTES API REQUEST
   * ------------------------------------------------------------
   */

  const requestBody = {
    origin: {
      location: {
        latLng: {
          latitude: normalizedOrigin.latitude,
          longitude: normalizedOrigin.longitude
        }
      }
    },

    destination: {
      location: {
        latLng: {
          latitude: normalizedDestination.latitude,
          longitude: normalizedDestination.longitude
        }
      }
    },

    intermediates: normalizedStops.map((stop) => ({
      location: {
        latLng: {
          latitude: stop.latitude,
          longitude: stop.longitude
        }
      }
    })),

    travelMode: 'DRIVE',

    routingPreference: 'TRAFFIC_AWARE',

    polylineQuality: 'HIGH_QUALITY',

    polylineEncoding: 'ENCODED_POLYLINE',

    departureTime: new Date(Date.now() + 60 * 1000).toISOString()
  }

  let response

  try {
    response = await fetch(
      'https://routes.googleapis.com/directions/v2:computeRoutes',
      {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json',

          'X-Goog-Api-Key': config.googleMapsApiKey,

          'X-Goog-FieldMask': [
            'routes.duration',
            'routes.staticDuration',
            'routes.distanceMeters',
            'routes.polyline.encodedPolyline'
          ].join(',')
        },

        body: JSON.stringify(requestBody)
      }
    )
  } catch (error) {
    console.error('[Google Routes] Network request failed:', error)

    throw Object.assign(
      new Error('Could not connect to Google Routes API.'),
      {
        status: 502,
        cause: error
      }
    )
  }

  /*
   * ------------------------------------------------------------
   * PROCESS RESPONSE
   * ------------------------------------------------------------
   */

  let payload

  try {
    payload = await response.json()
  } catch (error) {
    throw Object.assign(
      new Error(
        `Google Routes API returned an invalid response (HTTP ${response.status}).`
      ),
      { status: 502 }
    )
  }

  if (!response.ok) {
    console.error('[Google Routes API ERROR]', payload?.error || payload)

    throw Object.assign(
      new Error(
        payload?.error?.message ||
          `Google Routes API returned HTTP ${response.status}.`
      ),
      {
        status: response.status,
        googleError: payload?.error || payload
      }
    )
  }

  const route = payload.routes?.[0]

  if (!route) {
    throw Object.assign(
      new Error('Google Routes API returned no route.'),
      { status: 502 }
    )
  }

  const distanceMeters = Number(route.distanceMeters)

  const durationSeconds = secondsFromDuration(route.duration)

  const staticSeconds = secondsFromDuration(route.staticDuration)

  const encodedPolyline =
    route.polyline?.encodedPolyline || null

  /*
   * ------------------------------------------------------------
   * TRAFFIC CONDITION
   * ------------------------------------------------------------
   */

  const ratio =
    staticSeconds > 0
      ? durationSeconds / staticSeconds
      : null

  let trafficCondition = 'UNKNOWN'

  if (ratio !== null) {
    if (ratio < 1.12) {
      trafficCondition = 'LOW'
    } else if (ratio < 1.35) {
      trafficCondition = 'MODERATE'
    } else {
      trafficCondition = 'HIGH'
    }
  }

  console.log(
    `[Google Routes] Success | Distance: ${distanceMeters}m | ` +
    `ETA: ${durationSeconds}s | Traffic: ${trafficCondition} | ` +
    `Polyline: ${encodedPolyline ? 'available' : 'missing'}`
  )

  /*
   * ------------------------------------------------------------
   * RETURN RESULT
   * ------------------------------------------------------------
   */

  return {
    distanceMeters,
    durationSeconds,
    trafficCondition,
    source: 'google-routes',
    encodedPolyline,
    polyline: encodedPolyline
  }
}